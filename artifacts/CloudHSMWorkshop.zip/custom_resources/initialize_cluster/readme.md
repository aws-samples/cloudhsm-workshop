Dependencies for lambda installed following this:

https://www.freecodecamp.org/news/escaping-lambda-function-hell-using-docker-40b187ec1e48/

Don't delete them from the project